package com.yourname.holdhands;

import net.minecraftforge.fml.common.Mod;

@Mod("holdhandsmod")
public class HoldHandsMod {
    public HoldHandsMod() {
        System.out.println("HoldHandsMod loaded!");
    }
}
